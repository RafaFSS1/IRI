from controller import GPS
from vehicle import Driver
import math

# === Initialization ===
driver = Driver()
time_step = int(driver.getBasicTimeStep())
MAX_SPEED = 65
driver.setCruisingSpeed(MAX_SPEED)

# === Devices ===
gps = driver.getDevice("gps")
gps.enable(time_step)

lidar = driver.getDevice("lidar")
lidar.enable(time_step)


