from controller import Robot, GPS
from vehicle import Driver

robot = Robot()
driver = Driver()

time_step = int(robot.getBasicTimeStep())
MAX_SPEED = 65

driver.setSteeringAngle(0.0)
driver.setCruisingSpeed(MAX_SPEED)

gps = robot.getDevice("gps")
gps.enable(time_step)

